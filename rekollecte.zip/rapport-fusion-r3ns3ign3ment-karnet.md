# Livraison fusion R3NS3IGN3M3NT + KARN3T

Date : 26 septembre 2026 — mis à jour le 26 septembre 2026 (phases 7 à 10 + ResourceBuilder)

## Périmètre de cette livraison

Cette livraison couvre désormais les phases 1 à 9 de la fusion entre le
registre visiteurs et KARN3T, ainsi que le démarrage de la phase 10 (recette).
Le formulaire de ressource simple d'origine a par ailleurs été remplacé par
**ResourceBuilder** (catalogue par catégorie et type) — voir section dédiée
plus bas.

Le principe implémenté est :

```text
Visiteur → formulaire QR → CheckIn → Client → KARN3T
```

Le visiteur saisit ses informations une seule fois. Lorsque KARN3T est actif, la visite crée ou retrouve automatiquement une fiche client exploitable pour les ressources, réservations, paiements et rappels.

## Phases réalisées

### Phase 1 — Modèle métier

- Le `CheckIn` reste l’historique individuel du passage.
- Un `CheckIn` peut maintenant être lié à un `Client` KARN3T.
- La relation est optionnelle afin de préserver le fonctionnement du Niveau 1.
- Les données ne sont pas supprimées lorsque KARN3T est désactivé.

### Phase 2 — Modèle backend

- Ajout de la relation nullable `CheckIn.client` vers `karnet.Client`.
- Ajout de la migration `checkins.0004_checkin_client`.
- Exposition de `client_id` et `client_name` dans l’API du registre.
- Le schéma de formulaire accepte `identity_role` : `full_name`, `phone` ou `email`.

### Phase 3 — Conversion visiteur → client

- Création automatique d’un client après une synchronisation valide lorsque KARN3T est actif.
- Recherche prioritaire par email.
- Recherche secondaire par téléphone normalisé.
- Création d’une nouvelle fiche si aucun client correspondant n’existe.
- Conservation de l’idempotence lors des renvois offline.
- Aucun client automatique lorsque KARN3T est désactivé.
- Retour API enrichi avec `client_id` et `client_action` (`created` ou `matched`).

### Phase 4 — Champs d’identité configurables

- Le FormBuilder permet d’associer un champ à :
  - Nom du client ;
  - Téléphone du client ;
  - Email du client ;
  - Aucun rôle.
- Les anciens formulaires restent compatibles grâce à la détection par type et libellé.

### Phase 5 — Dashboard Clients

- Lorsque KARN3T est désactivé, le dashboard reste présenté comme `Registre`.
- Lorsque KARN3T est actif, le dashboard devient `Clients`.
- Le tableau affiche le client lié à chaque passage.
- Les textes vides et compteurs s’adaptent au contexte `Client` ou `Visiteur`.

### Phase 6 — Navigation fusionnée

Lorsque KARN3T est actif, la navigation globale devient :

```text
Clients
Mode Staff / Accueil
Paramètres
KARN3T
```

Dans l’espace KARN3T :

```text
Vue d’ensemble
Ressources
Réservations
Paiements
Rappels
Audit
```

L’ancien onglet interne `Visiteurs` n’est plus présenté dans la navigation principale. Le hub KARN3T renvoie vers l’espace global `Clients`.

### Phase 7 — Fiche client complète

- Nouvelle page `/dashboard/karnet/clients/<id>` : coordonnées, compteurs calculés côté serveur (`checkins_count`, `reservations_count`, `last_visit_at`), solde dû, historique des passages (réponses du formulaire d’origine, en accordéon), réservations/paiements du client.
- Action directe `Créer une réservation` depuis la fiche (préremplit le client dans le formulaire de réservation).
- Nom du client cliquable depuis le tableau `CheckInsTable` vers sa fiche.
- Décision actée : `/dashboard/karnet/visiteurs` redirige désormais vers `/dashboard` (l’ancien onglet interne n’a plus de raison d’exister, la fiche client le remplace).
- Nouveau filtre `?client=<id>` sur `GET /checkins/` pour l’historique de la fiche.

### Phase 8 — Parcours de réservation depuis Clients

- Formulaire de réservation réorganisé : sélection d’un client existant en première étape, `+ Nouveau client` repositionné comme parcours de secours.
- Préremplissage automatique depuis `?client=<id>` (lien direct depuis la fiche client).
- Alerte de conflit affichée avant l’envoi si la ressource choisie est déjà occupée par une réservation en cours (en plus du blocage serveur à 409 déjà existant).
- Lien vers la fiche client depuis chaque ligne de la liste des réservations.

### Phase 9 — Permissions et règles métier finales

- Confirmation des règles déjà en place : Patron/Gérant gèrent ressources et prix ; Patron/Gérant/Staff utilisent les clients et créent des réservations selon les capacités activées.
- Nouvelle règle métier : **annuler un encaissement déjà enregistré** (`is_paid: true → false`) est réservé à Patron/Gérant — encaisser reste ouvert à toute l’équipe. Appliquée côté API (403 sinon) et reflétée dans l’interface Paiements (bouton « Annuler » visible seulement pour Patron/Gérant).
- Règles métier hôtelières (chambre, durée, arrivée/départ, disponibilité) confirmées comme déjà couvertes par le calcul `ends_at` (jour/heure) et la détection de conflit existante ; aucun changement de modèle nécessaire pour la V1.

### Phase 10 — Recette complète (en cours)

- Tests automatisés ajoutés pour les scénarios vérifiables sans appareil physique : doublons avec téléphone formaté différemment (espaces, tirets), doublons avec email de casse différente, réactivation de KARN3T après désactivation (capacités et données préservées).
- **Limite confirmée par les tests** (déjà notée plus bas comme point technique) : un numéro local (`0701020304`) et sa forme internationale (`+2250701020304`) créent aujourd’hui deux fiches distinctes — pas un bug de cette livraison, un point de normalisation encore à traiter.
- Scénarios nécessitant un vrai appareil/réseau (parcours hôtelier desktop/mobile, QR multi-téléphones, mode tablette, offline réel, synchronisation de plusieurs fiches) documentés en checklist manuelle dans `docs/phase-10-recette.md` — **à dérouler avant ouverture commerciale**, non automatisable dans cette livraison.

## ResourceBuilder — catalogue de ressources par catégorie

Le formulaire de création de ressource (nom / unité / prix uniquement) est
remplacé par **ResourceBuilder** : un assistant par catégorie (Hébergement,
Beauté et soins, Espaces professionnels, Événementiel et restauration,
Stationnement, Sport et loisirs, Autre) avec types prêts à l’emploi (chambre
double, fauteuil de coiffure, bureau individuel…) et champs enrichis (capacité,
code/référence, emplacement, équipements, description, mode de tarification).

- Migration `karnet.0002_resource_builder_fields` : ajoute `category`,
  `resource_type`, `billing_unit`, `code`, `description`, `capacity`,
  `location`, `duration_label`, `equipment` sur `Resource`.
- Le champ historique `unit` (jour/heure/unité), seul connu du moteur de
  réservation (calcul de `ends_at`, détection de conflit), est **dérivé
  automatiquement** de `billing_unit` (par heure/séance → heure ; par jour/nuit
  → jour ; par mois/forfait → unité, sans blocage de créneau). Un appel qui
  fixe encore `unit` directement sans `billing_unit` reste pris en charge à
  l’identique (compatibilité ascendante testée).
- Chaque ressource est enregistrée immédiatement à la création/modification
  (POST/PATCH un par un), pas dans un brouillon local poussé en bloc à la fin —
  plus sûr si l’onglet se ferme en cours de route, cohérent avec le reste de
  l’application.
- Proposé automatiquement juste après l’activation de KARN3T
  (`Paramètres > Administration`), avec une option explicite « Plus tard ».

## Fichiers inclus

### Livraison initiale (phases 1 à 6)

- `backend/apps/checkins/models.py`
- `backend/apps/checkins/migrations/0004_checkin_client.py`
- `backend/apps/checkins/services.py`
- `backend/apps/checkins/serializers.py`
- `backend/apps/checkins/tests/test_sync.py`
- `frontend/src/types/index.ts`
- `frontend/src/components/FormBuilder.tsx`
- `frontend/src/components/CheckInsTable.tsx`
- `frontend/src/components/dashboard/Sidebar.tsx`
- `frontend/src/components/dashboard/MobileNav.tsx`
- `frontend/src/app/dashboard/page.tsx`
- `frontend/src/app/dashboard/layout.tsx`
- `frontend/src/app/dashboard/karnet/page.tsx`
- `frontend/src/app/dashboard/karnet/layout.tsx`
- `frontend/src/app/dashboard/parametres/administration/page.tsx`

### Ajouts phases 7 à 9

- `backend/apps/checkins/views.py` (filtre `?client=`)
- `backend/apps/checkins/tests/test_client_filter.py`
- `backend/apps/karnet/serializers.py`
- `backend/apps/karnet/views.py`
- `backend/apps/karnet/tests/test_karnet.py`
- `frontend/src/app/dashboard/karnet/clients/[id]/page.tsx`
- `frontend/src/app/dashboard/karnet/visiteurs/page.tsx` (converti en redirection)
- `frontend/src/app/dashboard/karnet/reservations/page.tsx`
- `frontend/src/app/dashboard/karnet/paiements/page.tsx`

### Ajouts phase 10 (tests) et ResourceBuilder

- `backend/apps/checkins/tests/test_sync.py` (doublons formats/casse)
- `backend/apps/organizations/tests/test_karnet.py` (réactivation)
- `backend/apps/karnet/models.py` (champs ResourceBuilder + dérivation `unit`)
- `backend/apps/karnet/migrations/0002_resource_builder_fields.py`
- `frontend/src/components/karnet/ResourceBuilder.tsx` (nouveau)
- `frontend/src/app/dashboard/karnet/ressources/page.tsx`
- `docs/phase-10-recette.md` (nouveau)
- `docs/cahier-des-charges.md`, `README.md` (mis à jour)

## Validation effectuée

- Tests backend : **65 tests passés** (56 initiaux + 9 ajoutés phases 7-10 et ResourceBuilder).
- Contrôle TypeScript (`tsc --noEmit`) : **OK**.
- `manage.py check` et `makemigrations --check` : **OK**.
- Migrations `checkins.0004_checkin_client` et `karnet.0002_resource_builder_fields` appliquées avec succès dans une base SQLite temporaire.
- Build Next.js production : **non vérifiable dans cet environnement de développement** — échoue uniquement sur la récupération réseau de la police Google Fonts (`Chelsea Market`), bloquée par le bac à sable de développement, sans rapport avec le code livré (import déjà présent avant cette livraison). À revérifier en environnement avec accès réseau complet avant mise en production.
- Aucun secret, `.env`, cache, dépendance ou build n’est inclus dans l’archive.

## Ce qui reste à faire

### Phase 10 — Recette complète (manuelle)

Voir `docs/phase-10-recette.md` pour le détail. En résumé, à dérouler sur
environnement de recette avant ouverture commerciale :

- Parcours hôtelier complet sur navigateur desktop et mobile.
- QR avec plusieurs téléphones simultanément.
- Mode tablette pour un visiteur sans téléphone.
- Offline réel (coupure réseau physique, fermeture/réouverture de l’onglet).
- Synchronisation de plusieurs fiches accumulées hors-ligne.
- Vérification visuelle de la désactivation/réactivation de KARN3T.

## Points techniques à traiter avant ouverture commerciale

- Ajouter une stratégie plus robuste contre les doublons concurrents lors de deux soumissions simultanées.
- ~~Normaliser les numéros locaux et internationaux de manière spécifique à la Côte d’Ivoire~~ — **corrigé** (voir section dédiée ci-dessous).
- Valider côté serveur les types et les champs autorisés dans chaque réponse de formulaire.
- Définir la durée de conservation des données visiteurs, signatures et documents.
- Vérifier et renforcer les limites de taille des photos, signatures et documents.
- Révoquer et régénérer immédiatement tout secret Cloudinary précédemment présent dans le script utilitaire de l’archive initiale.
- Vérifier les variables Vercel, Render et Neon avant déploiement.

## Limite de cette livraison

Cette archive est une livraison locale préparée et validée en build/tests (à l’exception du build Next.js, bloqué par le réseau du bac à sable — voir « Validation effectuée »). Elle n’est pas un déploiement en production. Les migrations `checkins.0004_checkin_client` et `karnet.0002_resource_builder_fields` devront être appliquées sur la base distante au moment du déploiement.

## Correctifs post-livraison — 27 septembre 2026

Suite à un signalement en production (logs Render + capture d'écran montrant
« Impossible de charger le registre » / « Hors ligne »).

### Normalisation téléphone Côte d'Ivoire — résolu

Le point technique listé plus haut est corrigé : `normalize_phone()`
reconnaît maintenant `0701020304`, `+2250701020304` et `00 225 07 01 02 03 04`
comme un seul et même numéro. Testé (`test_sync_matches_same_client_with_dashes_or_country_code_variants`,
`test_normalize_phone_leaves_non_ivorian_numbers_untouched`). Les numéros hors
Côte d'Ivoire ne sont pas affectés.

### Bug critique de session en production — résolu

Deux bugs cumulatifs expliquaient le blocage observé :

1. `AuthContext.restoreSession()` (frontend) affichait l'utilisateur en cache
   comme « authentifié » même après un rejet **définitif** du rafraîchissement
   de token (401/403 confirmé serveur) — le garde de redirection vers la
   connexion ne se déclenchait donc jamais, et l'utilisateur restait sur un
   dashboard où chaque appel API échouait en boucle.
2. `networkMonitor.ts` ciblait `http://localhost:8000` en production au lieu
   du proxy Next.js same-origin (`/api/v1`), faisant échouer son test de
   connectivité en permanence et afficher un badge « Hors ligne » trompeur
   même quand l'API répondait normalement.

Les deux sont corrigés. **À vérifier côté infrastructure (hors code)** : que
`SECRET_KEY` sur Render est une valeur fixe, jamais régénérée entre deux
déploiements — une rotation invaliderait d'un coup tous les jetons émis avant
le redéploiement, ce qui correspond exactement à la vague de 401 observée
dans les logs fournis.

**Confirmé par l'établissement : c'était bien le cas, et c'est plus grave
qu'une simple instabilité.** `SECRET_KEY` sur Render était littéralement le
placeholder de `backend/.env.example` (`change-moi-en-production...`), jamais
remplacé par une vraie clé. N'importe qui connaissant ou devinant ce
placeholder (visible dans le dépôt) peut forger un JWT valide pour n'importe
quel compte, y compris Patron — faille de sécurité critique, pas seulement une
cause de 401. `core/settings.py` refuse désormais de démarrer en production
si `SECRET_KEY` correspond à un placeholder connu ou fait moins de 32
caractères (testé : placeholder rejeté, clé courte rejetée, clé aléatoire
acceptée). **Reste à faire côté Render, immédiatement** : générer une vraie
clé aléatoire, la définir en variable d'environnement, redéployer (tout le
monde sera déconnecté une fois, c'est attendu), puis vérifier
`PLATFORM_ADMIN_PASSWORD` par la même occasion (même risque si le placeholder
y a aussi été copié tel quel).

### Journal d'audit — pagination ajoutée

`/auth/audit/` renvoyait un tableau brut plafonné à 100 événements
(`AuditEvent.objects...[:100]`), sans le signaler et sans moyen de remonter
au-delà. Remplacé par le même contrat de pagination que le registre (`page`,
`page_size`, `count`, `next`, `previous`), avec bouton « Charger plus » côté
Administration.

### Fichiers modifiés

- `backend/apps/checkins/services.py` (normalisation téléphone)
- `backend/apps/checkins/tests/test_sync.py` (tests mis à jour/ajoutés)
- `backend/apps/accounts/views.py` (pagination audit)
- `backend/apps/accounts/tests/test_audit_pagination.py` (nouveau)
- `frontend/src/context/AuthContext.tsx` (session expirée détectée correctement)
- `frontend/src/lib/networkMonitor.ts` (proxy same-origin en production)
- `frontend/src/app/dashboard/parametres/administration/page.tsx` (pagination + « Charger plus »)
- `backend/core/settings.py` (garde-fou SECRET_KEY au démarrage en production)

### Validation

68 tests backend passants, `manage.py check` OK, `tsc --noEmit` sans erreur.

## OCR pièce d'identité côté serveur — 27 septembre 2026

Lecture déplacée de `tesseract.js` (navigateur) vers `pytesseract` (serveur) :
nouveau module `backend/apps/checkins/ocr_utils.py`, vue `DocumentOcrView`,
route `public/forms/<qr_token>/ocr/`, throttle `ocr: 6/min`, tests dédiés
(`test_document_ocr.py`), `backend/Dockerfile` (tesseract-ocr + langue
française), `DocumentScanner.tsx` migré, `tesseract.js` retiré. Vérifié de bout
en bout avec un vrai Tesseract sur une CNI synthétique. **Basculer Render en
runtime Docker est indispensable** : le runtime natif interdit `apt-get`.
