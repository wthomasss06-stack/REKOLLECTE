"""Un GERANT peut inviter du STAFF au quotidien, mais ne peut jamais s'octroyer
ou octroyer un pair GERANT — seul le BOSS accorde ce niveau (cf. cahier des charges,
matrice de permissions patron > gerant > staff)."""
from apps.accounts.models import AuditEvent, StaffInvitation

from apps.testing_utils import auth_client


def test_boss_can_invite_gerant(db, boss_user, organization):
    client = auth_client(boss_user)

    response = client.post(
        "/api/v1/auth/invite/", {"email": "futur-gerant@example.com", "role": "GERANT"}, format="json"
    )

    assert response.status_code == 201
    assert StaffInvitation.objects.get(email="futur-gerant@example.com").role == "GERANT"


def test_gerant_can_invite_staff(db, gerant_user, organization):
    client = auth_client(gerant_user)

    response = client.post(
        "/api/v1/auth/invite/", {"email": "futur-agent@example.com", "role": "STAFF"}, format="json"
    )

    assert response.status_code == 201
    assert StaffInvitation.objects.get(email="futur-agent@example.com").role == "STAFF"


def test_gerant_cannot_invite_another_gerant(db, gerant_user, organization):
    client = auth_client(gerant_user)

    response = client.post(
        "/api/v1/auth/invite/", {"email": "autre-gerant@example.com", "role": "GERANT"}, format="json"
    )

    assert response.status_code == 403
    assert not StaffInvitation.objects.filter(email="autre-gerant@example.com").exists()


def test_staff_cannot_invite_anyone(db, staff_user, organization):
    client = auth_client(staff_user)

    response = client.post(
        "/api/v1/auth/invite/", {"email": "quelquun@example.com"}, format="json"
    )

    assert response.status_code == 403


def test_invite_defaults_to_staff_role(db, boss_user, organization):
    """Si le patron ne precise rien, l'invitation est STAFF par defaut (le niveau
    le plus restreint) — jamais un role plus permissif par defaut."""
    client = auth_client(boss_user)

    response = client.post("/api/v1/auth/invite/", {"email": "sans-role@example.com"}, format="json")

    assert response.status_code == 201
    assert StaffInvitation.objects.get(email="sans-role@example.com").role == "STAFF"


def test_invite_blocked_once_role_cap_reached(db, boss_user, organization):
    """5 agents max par organisation (invitations en attente comprises) — la 6e
    est refusee avant meme d'etre creee."""
    client = auth_client(boss_user)
    for i in range(5):
        resp = client.post("/api/v1/auth/invite/", {"email": f"agent{i}@example.com"}, format="json")
        assert resp.status_code == 201

    response = client.post("/api/v1/auth/invite/", {"email": "agent-en-trop@example.com"}, format="json")

    assert response.status_code == 400
    assert not StaffInvitation.objects.filter(email="agent-en-trop@example.com").exists()
    assert StaffInvitation.objects.filter(organization=organization, role="STAFF").count() == 5


def test_boss_can_revoke_pending_invitation(db, boss_user, organization):
    invitation = StaffInvitation.objects.create(organization=organization, email="a-revoquer@example.com", role="STAFF", token="token-revocation", invited_by=boss_user)
    response = auth_client(boss_user).post(f"/api/v1/auth/team/invitations/{invitation.id}/revoke/", {"reason": "Départ du recrutement"}, format="json")
    invitation.refresh_from_db()
    assert response.status_code == 200
    assert invitation.revoked_at is not None
    assert AuditEvent.objects.filter(action="invitation.revoked", target_invitation=invitation).exists()


def test_boss_can_revoke_member_and_next_login_is_blocked(db, boss_user, staff_user, organization):
    response = auth_client(boss_user).post(f"/api/v1/auth/team/members/{staff_user.id}/revoke/", {"reason": "Vous ne faites plus partie du staff."}, format="json")
    staff_user.refresh_from_db()
    assert response.status_code == 200
    assert staff_user.is_active is False
    assert staff_user.access_revoked_reason == "Vous ne faites plus partie du staff."
    assert AuditEvent.objects.filter(action="member.revoked", target_user=staff_user).exists()
